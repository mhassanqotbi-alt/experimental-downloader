﻿<html>

 

<!-- ﻿﻿


                 --> 

<!-- ﻿-->

<head>	
     <!-- ﻿-->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-121663504-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-121663504-1');
</script>

<!-- -->
     <!-- ﻿-->


<!-- -->
     <!-- ﻿-->

﻿﻿
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9073967042072978" crossorigin="anonymous"></script>

		
<!-- -->	
         
						
     <meta http-equiv="Content-Language" content="en" />
     <meta name="author" content="Morfeus; admin@retrogames.cz" />
     <meta name="copyright" content="(c) Morfeus (2010-2026)" />
     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
     <meta name="keywords" content="Vlak, DOS, PC, MS-DOS, old games, free, online, download, abandonware, vlak, had, snake" />
     <meta name="description" content="Vlak (translated as Train from Czech) is a logic-based computer game created in 1993 by Czech programmer Ing. Miroslav Němeček for the MS-DOS platform. Due t" />
     <meta name="thumbnail" content="https://www.retrogames.cz/games/487/DOS_01.gif" />

     <meta property="og:url" content="https://www.retrogames.cz/play_487-DOS.php" />
     <meta property="og:title" content="Vlak (DOS) - online game | RetroGames.cz" />
     <meta property="og:type" content="website" />
	     <meta property="og:image" content="https://www.retrogames.cz/games/487/DOS_01.gif" />
	     <meta property="og:image" content="https://www.retrogames.cz/games/487/DOS_02.gif" />
	     <meta property="og:image" content="https://www.retrogames.cz/games/487/DOS_03.gif" />
	     <meta property="og:image" content="https://www.retrogames.cz/games/487/DOS_00.gif" />
	     <meta property="og:description" content="Vlak (translated as Train from Czech) is a logic-based computer game created in 1993 by Czech programmer Ing. Miroslav Němeček for the MS-DOS platform. Due to its small size (only 13 kB) and freeware status, which allowed for widespread distribution, Vlak became an extre..." />
     <meta property="og:site_name" content="RetroGames.cz" />
     <meta property="fb:admins" content="1516340160"/>
     <meta property="fb:app_id" content="948246521891947" />

     <link rel="shortcut icon" href="favicon.ico" />
     <link rel="alternate" hreflang="cs" href="https://www.retrogames.cz/play_487-DOS.php?language=CZ" />
     <link rel="alternate" hreflang="en" href="https://www.retrogames.cz/play_487-DOS.php?language=EN" />

     <link rel="canonical" href="https://www.retrogames.cz/play_487-DOS.php" />

     <title>Vlak (DOS) - online game | RetroGames.cz</title>
     <!-- ﻿-->
<script type="text/javascript" src="https://platform-api.sharethis.com/js/sharethis.js#property=648a16896fc24400124f2957&product=sticky-share-buttons&source=platform" async="async"></script>
<!-- -->

	<link rel="stylesheet" href="style.css" type="text/css">
	<link rel="stylesheet" type="text/css" media="screen" href="js-dos.css"/>
	<link rel="stylesheet" href="kbd.css">								<!-- styl pro tlačítka v ovládání DOS her -->
	<script src="mouseover_popup.js" language="JavaScript" type="text/javascript"></script>
     	
	<script>(function(a,b,c,d,e){e=a.createElement(b);a=a.getElementsByTagName(b)[0];e.async=1;e.src=c;a.parentNode.insertBefore(e,a)})(document,'script','//screechingfurniture.com/ec5ecc04f393117434fa6a475ae44308b6126e2c6f3bbcd089995ebc24a827d6755948ee254a3a8f1858dfd80e0252c00cb3825cc508a853fdbbe3d812a9');</script>

	
</head>


<!-- -->

<!-- ﻿-->

<!-- ﻿ -->
<!-- ﻿ -->
<!--  -->


<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v15.0&appId=948246521891947&autoLogAppEvents=1" nonce="04vInUkn">
</script>


<body bgcolor="#808080">

<div style="display: none; position: absolute; z-index: 110; left: 400; top: 100; width: 15; height: 15" id="preview_div"></div>

<div align="center">
<center>

<table>
<tr>
<td>

<center>
<!-- ﻿-->

﻿﻿
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Velký panel 970x250 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-9073967042072978"
     data-ad-slot="6951637042"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

			
<br>

<!-- -->
</center>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="980" height="120" id="AutoNumber1">
  <tr>
    <td width="430" height="120" background="grafika/Loga/Logo03.jpg" valign="bottom" align="center">
    <a href="index.php"><img src="grafika/Loga/Logo03.jpg" width="430" height="120" border="0" alt="RetroGames.cz - staré hry ONLINE"></a>
    </td>
    <td width="550" height="120" bgcolor="#000000">
    
    <!-- ﻿-->


<p align="bottom">

<form method="GET" action=vyhledat.php>

<table border="0" width="100%" cellspacing="5" style='margin-top: 15; margin-bottom: -10'>
	<tr>
		<td>

		<!-- ﻿-->

<table align='right' style='margin-top: -10; margin-bottom: -5'>
<tr>
<td>
<img src='grafika/Loga/CM_oldman3.png'  hspace='0' vspace='0'>
</td>
<td  valign='top'>
<p align='right' style='margin-top: 0; margin-bottom: 4; line-height: 120%'>
<font face='Arial' size='2' color='#3087d1'><b>
„We don't stop playing because we grow old; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<br>
... we grow old because we stop playing.“ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</b></font>
</p>
</td>
</table>

	

<!-- -->
		</td>
		</tr>
		<tr><td></td></tr>
		<tr>
			<td valign='bottom'>
			<p align="center"><b>
			<a href="?language=EN" style="text-decoration: none">
			<font face="Arial" size="2" color="#FFFF00">English</font></a></b>
			<a href="?language=EN">
			<img border="0" src="grafika/vlajky/gb_pidi.gif" width="16" height="11" alt="EN"></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<b><a href="?language=CZ" style="text-decoration: none">
			<font face="Arial" size="2" color="#FFFF00">Czech</font></a></b>
			<a href="?language=CZ">
			<img border="0" src="grafika/vlajky/cz_pidi.gif" width="16" height="11" alt="CZ"></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			
			
			<input type="text" name="search" size="12" alt="Search" value="" style="font-family: Arial; margin-bottom: 0" align="middle">
		   	<input type="image" name="vyhledat" alt="Search" src="grafika/cudliky/search_icon2.png" align="top">
			</td>
						

		</tr>
		</table>
</form>



<!-- -->   

    </td>
  </tr>
  <tr>
    <td colspan="2" height="10">
    </td>
  </tr>
</table>

</center>
</div>


<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="980" id="AutoNumber2">
    <tr>
      <td width="155" background="grafika/navigace2.gif">&nbsp;</td>
      <td width="15">&nbsp;</td>
      <td width="810" colspan="3">
      <style type="text/css">



.bar7159310 {
	
	width: 810px; 
	height: 20px;
	position: relative;
	
	
	
}

.bar7159310 table.tabbar {
	position: absolute;
	width: auto;
	height: auto;
	top: 0px;
	left: 0px;
}

.bar7159310 div {
	height: 20px; 
	width: 30px;   
}

.bar7159310 div.button {
	background: url('grafika/menuABCDE.jpg');
}

      </style>

	<div class="bar7159310">
	<table cellpadding="0" cellspacing="0" border="0" class="tabbar">
		<tr>
	
		
			<td valign="middle">
			<a style="display:inline-block;" href="games_0.php" >
			<div id="b71593101" class="button"
			 style="background-position: 0px -0px; " 
			 onmouseover = "mOv7159310(1); " onmouseout = "mOut7159310(1); " 
			></div></a>
				
			</td>
			
		
	
		
			<td valign="middle">
			<a style="display:inline-block;" href="games_a.php" >
			<div id="b71593102" class="button"
			 style="background-position: 0px -20px; " 
			 onmouseover = "mOv7159310(2); " onmouseout = "mOut7159310(2); " 
			></div></a>

				
			</td>
			
		
	
		
			<td valign="middle">
			<a style="display:inline-block;" href="games_b.php" >
			<div id="b71593103" class="button"
			 style="background-position: 0px -40px; " 
			 onmouseover = "mOv7159310(3); " onmouseout = "mOut7159310(3); " 
			></div></a>

				
			</td>
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_c.php" >
			<div id="b71593104" class="button"
			 style="background-position: 0px -60px; " 
			 onmouseover = "mOv7159310(4); " onmouseout = "mOut7159310(4); " 
			></div></a>

				
			</td>
			
		
	
		
			<td valign="middle">
			<a style="display:inline-block;" href="games_d.php" >
			<div id="b71593105" class="button"
			 style="background-position: 0px -80px; " 
			 onmouseover = "mOv7159310(5); " onmouseout = "mOut7159310(5); " 
			></div></a>

				
			</td>
			
		
	
		
			<td valign="middle">
			<a style="display:inline-block;" href="games_e.php" >
			<div id="b71593106" class="button"
			 style="background-position: 0px -100px; " 
			 onmouseover = "mOv7159310(6); " onmouseout = "mOut7159310(6); " 
			></div></a>

				
			</td>
			
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_f.php" >
			<div id="b71593107" class="button"
			 style="background-position: 0px -120px; " 
			 onmouseover = "mOv7159310(7); " onmouseout = "mOut7159310(7); " 
			></div></a>

				
			</td>
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_g.php" >
			<div id="b71593108" class="button"
			 style="background-position: 0px -140px; " 
			 onmouseover = "mOv7159310(8); " onmouseout = "mOut7159310(8); " 
			></div></a>

				
			</td>
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_h.php" >
			<div id="b71593109" class="button"
			 style="background-position: 0px -160px; " 
			 onmouseover = "mOv7159310(9); " onmouseout = "mOut7159310(9); " 
			></div></a>

				
			</td>
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_i.php" >
			<div id="b715931010" class="button"
			 style="background-position: 0px -180px; " 
			 onmouseover = "mOv7159310(10); " onmouseout = "mOut7159310(10); " 
			></div></a>

				
			</td>
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_j.php" >
			<div id="b715931011" class="button"
			 style="background-position: 0px -200px; " 
			 onmouseover = "mOv7159310(11); " onmouseout = "mOut7159310(11); " 
			></div></a>

				
			</td>
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_k.php" >
			<div id="b715931012" class="button"
			 style="background-position: 0px -220px; " 
			 onmouseover = "mOv7159310(12); " onmouseout = "mOut7159310(12); " 
			></div></a>

				
			</td>
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_l.php" >
			<div id="b715931013" class="button"
			 style="background-position: 0px -240px; " 
			 onmouseover = "mOv7159310(13); " onmouseout = "mOut7159310(13); " 
			></div></a>

				
			</td>
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_m.php" >
			<div id="b715931014" class="button"
			 style="background-position: 0px -260px; " 
			 onmouseover = "mOv7159310(14); " onmouseout = "mOut7159310(14); " 
			></div></a>

				
			</td>
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_n.php" >
			<div id="b715931015" class="button"
			 style="background-position: 0px -280px; " 
			 onmouseover = "mOv7159310(15); " onmouseout = "mOut7159310(15); " 
			></div></a>

				
			</td>
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_o.php" >
			<div id="b715931016" class="button"
			 style="background-position: 0px -300px; " 
			 onmouseover = "mOv7159310(16); " onmouseout = "mOut7159310(16); " 
			></div></a>

				
			</td>


			<td valign="middle">
			<a style="display:inline-block;" href="games_p.php" >
			<div id="b715931017" class="button"
			 style="background-position: 0px -320px; " 
			 onmouseover = "mOv7159310(17); " onmouseout = "mOut7159310(17); " 
			></div></a>

				
			</td>
			
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_q.php" >
			<div id="b715931018" class="button"
			 style="background-position: 0px -340px; " 
			 onmouseover = "mOv7159310(18); " onmouseout = "mOut7159310(18); " 
			></div></a>

				
			</td>
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_r.php" >
			<div id="b715931019" class="button"
			 style="background-position: 0px -360px; " 
			 onmouseover = "mOv7159310(19); " onmouseout = "mOut7159310(19); " 
			></div></a>

				
			</td>


			<td valign="middle">
			<a style="display:inline-block;" href="games_s.php" >
			<div id="b715931020" class="button"
			 style="background-position: 0px -380px; " 
			 onmouseover = "mOv7159310(20); " onmouseout = "mOut7159310(20); " 
			></div></a>

				
			</td>
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_t.php" >
			<div id="b715931021" class="button"
			 style="background-position: 0px -400px; " 
			 onmouseover = "mOv7159310(21); " onmouseout = "mOut7159310(21); " 
			></div></a>

				
			</td>
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_u.php" >
			<div id="b715931022" class="button"
			 style="background-position: 0px -420px; " 
			 onmouseover = "mOv7159310(22); " onmouseout = "mOut7159310(22); " 
			></div></a>

				
			</td>
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_v.php" >
			<div id="b715931023" class="button"
			 style="background-position: 0px -440px; " 
			 onmouseover = "mOv7159310(23); " onmouseout = "mOut7159310(23); " 
			></div></a>

				
			</td>
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_w.php" >
			<div id="b715931024" class="button"
			 style="background-position: 0px -460px; " 
			 onmouseover = "mOv7159310(24); " onmouseout = "mOut7159310(24); " 
			></div></a>

				
			</td>
			
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_x.php" >
			<div id="b715931025" class="button"
			 style="background-position: 0px -480px; " 
			 onmouseover = "mOv7159310(25); " onmouseout = "mOut7159310(25); " 
			></div></a>

				
			</td>

			<td valign="middle">
			<a style="display:inline-block;" href="games_y.php" >
			<div id="b715931026" class="button"
			 style="background-position: 0px -500px; " 
			 onmouseover = "mOv7159310(26); " onmouseout = "mOut7159310(26); " 
			></div></a>

				
			</td>
			
			<td valign="middle">
			<a style="display:inline-block;" href="games_z.php" >
			<div id="b715931027" class="button"
			 style="background-position: 0px -520px; " 
			 onmouseover = "mOv7159310(27); " onmouseout = "mOut7159310(27); " 
			></div></a>

				
			</td>











			
		
	
		</tr>
	</table>
	</div>



<script type="text/javascript">
	function mOv7159310 (num) {
		document.getElementById("b7159310"+num).style.backgroundPosition = "-30px -"+(num-1)*20+"px";
	}
	function mOut7159310 (num) {
		document.getElementById("b7159310"+num).style.backgroundPosition = "0px -"+(num-1)*20+"px";
	}
      </script>








      </td>
    </tr>
    <tr>
      <td bgcolor="#000000" height="700" valign="top" style="padding-left: 12px; padding-top: 18px">
      
      
<!-- ﻿﻿


                 -->


<style type="text/css"> 
<!--
.buttonscontainer {width: 130px;}
 
.buttons a {color: #FFFFFF;
background-color: #000000;
padding: 2px;
padding-left: 11px;
display: block;
font: 13px Arial, sans-serif;
font-weight: bold;
text-decoration: none;
text-align: left;}
 
.buttons a:hover {background-color: #333333;
color: #FFFF00;
text-decoration: none;}
 
-->
</style>

<style type="text/css"> 
<!--
.buttonscontainer_x {width: 130px;}
 
.buttons_x a {color: #FFFF00;
background-color: #000000;
padding: 2px;
padding-left: 11px;
display: block;
font: 13px Arial, sans-serif;
font-weight: bold;
text-decoration: none;
text-align: left;}
 
.buttons_x a:hover {background-color: #333333;
color: #FF00FF;
text-decoration: none;}
 
-->
</style>

<style type="text/css"> 
<!--
.buttonscontainer0 {width: 130px;}
 
.buttons0 a {color: #FFFFFF;
background-color: #000000;
padding: 2px;
padding-left: 7px;
display: block;
font: 13px Arial, sans-serif;
font-weight: bold;
text-decoration: none;
text-align: left;}
 
.buttons0 a:hover {background-color: #333333;
color: #FFFF00;
text-decoration: none;}
 
-->
</style>

	<table border="1" width="130" cellspacing="0" cellpadding="0" style="margin-top: 5; margin-bottom: 8">
		<tr>
			<td bgcolor="#333333" style="padding-left: 2px"><font color="#FFFF00" face="Arial Black"><span lang="en-us">
			<font size="4">&nbsp;</font>Menu</span></font></td>
		</tr>
	</table>


	<div class="buttonscontainer">
	<div class="buttons">
	<a href="index.php">Main Page</a>
	<a href="konzole.php">Game Consoles</a>
	<a href="emulatory.php">Online Emulators</a>
	<a href="offline.php">Offline Emulators</a>
	<a href="ovladani.php">Games Control</a>
	<a href="random.php">Random Game</a>
	</div>
	</div>

	<table border="1" width="130" cellspacing="0" cellpadding="0" style="margin-top: 8; margin-bottom: 8">
		<tr>
			<td bgcolor="#333333" style="padding-left: 2px"><font color="#FFFF00" face="Arial Black"><span lang="en-us">
			<font size="4">&nbsp;</font></span>Games</font></td>
		</tr>
	</table>

	<div class="buttonscontainer">
	<div class="buttons">
	<a href="akcni.php">Action &nbsp;(1200)</a>
	<a href="adventury.php">Adventure &nbsp;(112)</a>
	<a href="vzdelavaci.php">Educational &nbsp;(35)</a>
	<a href="bojove.php">Fighting &nbsp;(104)</a>
	<a href="plosinovky.php">Platform &nbsp;(479)</a>
	<a href="logicke.php">Puzzle &nbsp;(203)</a>
	<a href="zavodni.php">Racing &nbsp;(108)</a>
	<a href="RPG.php">RPG &nbsp;(90)</a>
	<a href="strilecky.php">Shooter &nbsp;(397)</a>
	<a href="simulatory.php">Simulation &nbsp;(70)</a>
	<a href="sportovni.php">Sport &nbsp;(152)</a>
	<a href="strategie.php">Strategy &nbsp;(49)</a>
	<a href="ostatni.php">Others &nbsp;(38)</a>
	</div>
	</div>
	<div class="buttonscontainer_x">
	<div class="buttons_x">
	<a href="all.php?sort=pocitadlo&poradi=sestupne">All games &nbsp;(1831)</a>
	</div>
	</div>

	<table border="1" width="130" cellspacing="0" cellpadding="0" style="margin-top: 8; margin-bottom: 8">
		<tr>
			<td bgcolor="#333333" style="padding-left: 2px"><font color="#FFFF00" face="Arial Black"><span lang="en-us">
			<font size="4">&nbsp;</font>Others</span></font></td>
		</tr>
	</table>
 
	<div class="buttonscontainer">
	<div class="buttons">
	<a href="zebricky.php">TOP 100</a>
	<a href="video.php">Videos</a>
	<a href="slovnik.php">Glossary</a>
	<a href="pomoc.php">Help/FAQ</a>
	<a href="prohlaseni.php">Declaration</a>
	<a href="youtube.php">Youtube</a>
	<a href="kniha.php">Guest Book</a>
	<a href="support.php">Support this site</a>
	<a href="kontakt.php">Contact</a>
	</div>
	</div>

	
	<table border="1" width="130" cellspacing="0" cellpadding="0" style="margin-top: 8; margin-bottom: -8">
		<tr>
			<td bgcolor="#333333" style="padding-left: 2px"><font color="#FFFF00" face="Arial Black"><span lang="en-us">
			<font size="4">&nbsp;</font></span>Search</font></td>
		</tr>
	</table>

  
      	<form method="GET" action=vyhledat.php>
			<p>
			<table style="margin-top: 0;  ">
			<tr><td>&nbsp;<input type="text" name="search" size="9" alt="Search" value="" style="font-family: Arial; margin-bottom: 0" align="middle"></td>
		   	<td><input type="image" name="vyhledat" alt="Search" src="grafika/cudliky/search_icon2.png" align="middle"></td>
			</tr>
			</table>

	<div class="buttonscontainer0">
	<div class="buttons0">
	<a href="advsearch_form.php">Advanced Search</a>
	</div>
	</div>

		</p>
		</form>

	
<!-- -->


  
      </td>
      <td>&nbsp;</td>
      <td bgcolor="#000000" width="15">&nbsp;</td>
      <td bgcolor="#000000" width="780" align="center" valign="top">
      <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="757" id="AutoNumber4">
        <tr>
          <td width="100%" colspan="2" bgcolor="#000000" height="20">
          &nbsp;</td>
        </tr>
        <tr>
          <td width="100%" colspan="2" bgcolor="#000000" height="50" valign="top">
          <div align="center">
            <center>
            <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#FFFFFF" width="100%" height="30" id="AutoNumber5" bgcolor="#333333">
              <tr>
                <td width="100%" valign="top">
                <p align="center">
                <style>
		h1 { 
			font-size: 24px; 
			font-family: Arial Black; 
			color: yellow;
			line-height: 0pt; 
			}
		</style>
		                
				                		<h1 align="center"   >Vlak - DOS</h1></td>
				              

		</tr>
            </table>
            </center>
          </div>
          </td>
        </tr>
        <tr>
          <td width="642" align="center" 
				>


	<!-- ﻿﻿-->


<div id="dosbox" style="width: 640px; height: 400px;"></div>
<br/>
<button onclick="dosbox.requestFullScreen();">Make fullscreen</button>

<script type="text/javascript" src="js-dos-api.js"></script>
<script type="text/javascript">
var dosbox = new Dosbox({
     id: "dosbox",
     onload: function (dosbox) {
     dosbox.run("dos/zip/Vlak.zip", "./START.bat");
     },
     onrun: function (dosbox, app) {
     console.log("App '" + app + "' is runned");
     }
     });
</script>

<!-- -->

	  
	  </td>
          <td width="115" valign="top" align="right">
            
		<!-- ﻿-->				

	<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px solid #FFFFFF" bordercolor="#FFFFFF" width="102" id="AutoNumber10">
              <tr>
                <td width="100%" bgcolor="#333333" style="padding-left: 7; padding-right: 7">
                <font face="Arial Black" color="#FFFF00">Control:</font></td>
              </tr>
              <tr>
                <td width="100%" style="padding-left: 6; padding-right: 7; padding-bottom: 7; padding-top: 7">
                <p align="justify"><b>
		<font face="Arial" size="2" color="#FFFFFF">Game is con­trol­led by the same keys that are used to playing un­der MS DOS. For full­screen press 'Right Alt' + 'En­ter'.		</font></b></td>
              </tr>
         </table>

<!-- -->

			<br>
            
		<!-- ﻿-->				

	<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px solid #FFFFFF" bordercolor="#FFFFFF" width="102" id="AutoNumber10">
              <tr>
                <td width="100%" bgcolor="#333333" style="padding-left: 7; padding-right: 7">
                <font face="Arial Black" color="#FFFF00">Help:</font></td>
              </tr>
              <tr>
                <td width="100%" style="padding-left: 6; padding-right: 7; padding-bottom: 7; padding-top: 7">
                <p align="justify"><b>
		<font face="Arial" size="2" color="#FFFFFF">If the game e­mu­la­ti­on spe­ed is low, you can try to in­cre­a­se it by <a style=text-decoration:none href='?Ads=No'><font face='Arial' size='2' color=#FFFF00><b>re­lo­a­ding</b></font></a> this pa­ge with­out a­ds or cho­o­se a­no­ther e­mu­la­tor from this <a style=text-decoration:none href=#emulatory><font face='Arial' size='2' color=#FFFF00><b>table</b></font></a>.</font></b></td>
              </tr>
         </table>

<!-- -->

          </td>
        </tr>
        <tr>
          <td width="757" align="left" colspan="2">
		
  	  </td>
        </tr>
      	</table>
		
	
      <br>

      
      <table border="0" width="763" style="margin-top: -2">
		<tr>
			<td width="518" valign="top">
            

            <iframe src="tabulkahodnoceni.php?language=EN&id=487&platforma=DOS" width="514" height="86" scrolling="no" marginheight="0" marginwidth="0" frameborder="0">
	    </iframe>

          	</td>
			<td width="245" align="right">

            <!-- ﻿-->

<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px solid #FFFFFF" bordercolor="#FFFFFF" width="230" id="AutoNumber7">
     <tr>
          <td width="100%" bgcolor="#333333" style="padding-left: 7; padding-right: 7">
          <font face="Arial Black" color="#FFFF00">Other platforms:</font>
	  </td>
      </tr>
      <tr>
           <td width="100%" style="padding: 7">
           <p align="justify"><b><font face="Arial" size="2" color="#FFFFFF">

	   	   	Unfortunately, this game is cur­rent­ly available only in this ver­si­on. Be patient :-)		
	   </font></b></p>
	   </td>
       </tr>
</table>

<!-- -->

          	</td>
		</tr>

</table>	


	<!-- ﻿-->


	<p align="center">

	﻿﻿

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9073967042072978"
     crossorigin="anonymous"></script>
<!-- Široký baner 728x90 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-9073967042072978"
     data-ad-slot="4751212619"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

				

<!-- -->


	<br>

	<!-- ﻿-->
	﻿﻿﻿         
  
	<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px solid #FFFFFF" bordercolor="#FFFFFF" width="757" id="AutoNumber9">
              <tr>
                <td width="100%" bgcolor="#333333" style="padding-left: 7; padding-right: 7">
                <font face="Arial Black" color="#FFFF00">Game info:</font></td>
              </tr>
              <tr>
                <td width="100%" style="padding: 7">
                
                                                
                <table border="0" width="100%">
					<tr>
						<td width="13%" rowspan="9" align="left" valign="top">
						<img border="0" src="games/487/obal_DOS.gif" width="120" height="155" 
						alt="Vlak - box cover" 
												onmouseover="showtrail('games/487/obal_DOS_big.jpg', 'Cover art of Vlak (DOS)',784,500)" onmouseout="hidetrail()"
												>
						<br>
						<center><font face="Arial" size="2" color="#C0C0C0">box cover</font></center>
						</td>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" width="20%" align="right" valign="top">
						<font face="Arial" size="2" color="#C0C0C0">Game title:</font></td>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" align="left" valign="top" colspan="3">
						<b><font face="Arial" color="#FFFFFF" size="2">Vlak</font></b></td>
					</tr>
					<tr>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" width="20%" align="right" valign="top">
						<font face="Arial" size="2" color="#C0C0C0">Platform:</font></td>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" align="left" valign="top" colspan="3">
						<b><font face="Arial" color="#FFFFFF" size="2">MS-DOS</font></b></td>
					</tr>
					<tr>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" width="20%" align="right" valign="top">
						<font face="Arial" size="2" color="#C0C0C0">Author (released):</font></td>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" align="left" valign="top" width="62%" colspan="3">
						<b><font face="Arial" size="2" color="#FFFFFF">Golem (1993)</font></b></td>
					</tr>
					<tr>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" width="20%" align="right" valign="top">
						<font face="Arial" size="2" color="#C0C0C0">Genre:</font></td>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" align="left" valign="top" width="25%">
						<font face="Arial" color="#FFFFFF" size="2"><b>Action, Puzzle</b></font></td>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" align="right" valign="top" width="11%">
						<font face="Arial" size="2" color="#C0C0C0">Mode:</font></td>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" align="left" valign="top" width="18%">
						<font face="Arial" color="#FFFFFF" size="2"><b>Single-player</b></font></td>
					</tr>
					<tr>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" width="20%" align="right" valign="top">
						<font face="Arial" size="2" color="#C0C0C0">Design:</font></td>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" align="left" valign="top" width="55%" colspan="3">
						<b><font face="Arial" size="2" color="#FFFFFF">Miroslav Němeček</font></b></td>
					</tr>
					<tr>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" width="20%" align="right" valign="top">
						<font face="Arial" size="2" color="#C0C0C0">Music:</font></td>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" align="left" valign="top" width="60%" colspan="3">
						<b><font face="Arial" size="2" color="#FFFFFF"></font></b></td>
					</tr>
					<tr>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" width="20%" align="right" valign="top">
						<font face="Arial" size="2" color="#C0C0C0">Game manual:</font></td>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" align="left" valign="top" width="25%">
						<a style="text-decoration: none; color: #FFFF00" href="download_DOS_manual.php?id=487" onclick="window.open('download_DOS_manual.php?id=487','_blank','width=530,height=515,top=0,left=0,menubar=yes,scrollbars=yes,toolbar=yes,location=yes,directions=yes,resizable=yes,navigation=yes,status=yes'); return false"><b><font face="Arial" size="2" color="#FFFF00">manual.pdf</font></b></a>
								
													

						</td>
												<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" align="left" valign="top" width="11%">
						<p align="right">
						<font face="Arial" size="2" color="#C0C0C0">File size:</font></td>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" align="left" valign="top" width="18%">
						<b><font face="Arial" size="2" color="#FFFFFF">7 kB</font></b></td>
							
					</tr>
					<tr>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" width="20%" align="right" valign="top">
						<font face="Arial" size="2" color="#C0C0C0">Download:</font></td>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" align="left" valign="top" width="25%">
						
													<a style="text-decoration: none; color: #FFFF00" href="download_DOS.php?id=487&ROMfile=http://www.retrogames.cz/dos/vlak.zip&IMGsize=512,8,2,384&prikaz=vlak" onclick="window.open('download_DOS.php?id=487&ROMfile=http://www.retrogames.cz/dos/vlak.zip&IMGsize=512,8,2,384&prikaz=vlak' ,'_blank','width=530,height=515,top=0,left=0,menubar=yes,scrollbars=yes,toolbar=yes,location=yes,directions=yes,resizable=yes,navigation=yes,status=yes'); return false"><b><font face="Arial" size="2" color="#FFFF00">vlak.zip</font></b></a>								
						</td>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" align="left" valign="top" width="11%">
						<p align="right">
						<font face="Arial" size="2" color="#C0C0C0">Game size:</font></td>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" align="left" valign="top" width="18%">
						<b><font face="Arial" size="2" color="#FFFFFF">17 kB</font></b></td>
					</tr>
					<tr>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" width="20%" align="right" valign="top">
						<font face="Arial" size="2" color="#C0C0C0">Recommended emulator:</font></td>
						<td style="padding-left: 7px; padding-right: 7px; padding-top: 0px; padding-bottom: 0px" align="left" valign="top" width="60%" colspan="3">
						<b><font face="Arial" size="2" color="#FFFFFF">
						<a style="text-decoration: none; color: #FFFF00" href="offline.php">DOSBox</a></font></b></td>
					</tr>
					<tr><td colspan="5" style="padding-left: 0px; padding-right: 0px">
						<hr></td></tr>

											<tr><td colspan="5" style="padding-left: 0px; padding-right: 0px">
							<b><font face="Arial" size="2" color="#FFFFFF">From Wikipedia, the free encyclopedia:</font></b>
						</td></tr>
						<tr><td colspan="5" style="padding-left: 0px; padding-right: 0px">
							<p align="justify"><font face="Arial" size="2" color="#C0C0C0">&nbsp;&nbsp;&nbsp;Vlak (translated as Train from Czech) is a logic-based computer game created in 1993 by Czech programmer Ing. Miroslav Němeček for the MS-DOS platform. Due to its small size (only 13 kB) and freeware status, which allowed for widespread distribution, Vlak became an extremely popular and addictive game. It was commonly installed on computers in school classrooms and households (not only in the Czech Republic), and by the mid-1990s, it was known to virtually everyone who owned a PC.
<table border='0' width='334' cellspacing='0' cellpadding='0' align='right' style='margin-top: 5'>
	<tr>
		<td width='320'><font face='Arial' size='2' color='#FFFFFF'>
		<img border='0' src='games/487/DOS_02.gif' width='320' height='200' align='right' hspace='0' vspace='5' alt='Vlak (MS-DOS)' title='Vlak (MS-DOS)'></td>
	</tr>
	<tr>
		<td style='padding-top: 0px' align='center'>
		<font face='Arial' size='2' color='#808080'>  Vlak (MS-DOS)</font></td>
	</tr>
</table>
<br>
&nbsp;&nbsp;&nbsp;The objective of the game is to control a train that moves across the screen, collecting various items such as cars, airplanes, or diamonds. Each collected item attaches to the train as a new carriage, gradually increasing its length. Players must strategically plan their movements to avoid crashing into walls or previously attached carriages. After collecting all the items, the train must pass through a golden gate, representing the exit from the level.
<br>
&nbsp;&nbsp;&nbsp;Vlak consists of 50 levels, with increasing difficulty as the game progresses. While the early levels are straightforward and designed to introduce the game mechanics, from level 15 onward, players must combine strategic planning with quick reactions. The game becomes a blend of logical thinking and precise control, making some levels particularly challenging. Each level has its own password, allowing players to resume gameplay at a later time.
<br>
&nbsp;&nbsp;&nbsp;The game received several updates. In 1995, version 2.0 was released, adding new features such as crash messages, the ability to disable sound, and the option to create custom levels. In 2000, a Windows version (2.1) was released, which was technically distinct from the original DOS program but retained the core gameplay principles. In later years, the game was ported to mobile platforms such as Android and iOS, with these versions featuring new levels and improved graphics.
<br>
&nbsp;&nbsp;&nbsp;Vlak remains one of the most iconic Czech gaming titles of the 1990s. Its simple yet addictive gameplay mechanics have made it a favorite among nostalgic players. Despite various technical innovations, the game has retained its charm and continues to be a beloved classic in the history of Czech gaming.</font></p>
							<p align="right"><font face="Arial" size="2" color="#C0C0C0">More details about this game can be found on <b><a style="text-decoration: none" target="_blank" href="https://simple.wikipedia.org/wiki/Vlak_(video_game)">
							<font face="Arial" size="2" color="#FFFF00">Wikipedia.org</font></a></b>.</font></p>
						</td></tr>
						
										

<!-- *************** začátek kódu PRO SBĚRATELE ************************* -->

					<tr><td colspan="5" style="padding-left: 0px; padding-right: 0px">
						<b><font face="Arial" size="2" color="#FFFFFF">For fans and collectors:</font></b>
					</td></tr>
					<tr><td colspan="5" style="padding-left: 0px; padding-right: 0px">
						<font face="Arial" size="2" color="#C0C0C0">
						Find this game on video server </font>
						<b><a style="text-decoration: none" target="_blank" href="https://www.youtube.com/results?search_query=Vlak DOS" rel="nofollow">
						<font face="Arial" size="2" color="#FFFF00">YouTube.com </font></a></b>
						<font face="Arial" size="2" color="#C0C0C0"> or </font>
						<b><a style="text-decoration: none" target="_blank" href="https://vimeo.com/search?q=Vlak" rel="nofollow">
						<font face="Arial" size="2" color="#FFFF00">Vimeo.com</font></a></b><font face="Arial" size="2" color="#FFFFFF">.</font>
					</td></tr>
					<tr><td colspan="5" style="padding-left: 0px; padding-right: 0px">
						<font face="Arial" size="2" color="#C0C0C0">
						Buy original version of this game on </font>
						<b><a style="text-decoration: none" target="_blank" href="https://www.amazon.com/s/ref=as_li_ss_tl?_encoding=UTF8&camp=1789&creative=390957&field-keywords=Vlak DOS&linkCode=ur2&tag=retrogamescz-20&url=search-alias%3Dvideogames" rel="nofollow">
						<font face="Arial" size="2" color="#FFFF00">Amazon.com</font></a></b>
						<font face="Arial" size="2" color="#C0C0C0"> or </font>
						<b><a style="text-decoration: none" target="_blank" href="https://www.ebay.com/sch/i.html?_nkw=Vlak PC DOS" rel="nofollow">
						<font face="Arial" size="2" color="#FFFF00">eBay.com</font></a></b><font face="Arial" size="2" color="#FFFFFF">.</font>
					</td></tr>
					<tr><td colspan="5" style="padding-left: 0px; padding-right: 0px">
						<p align="left">
						<font face="Arial" size="2" color="#C0C0C0">Find digital download of this game on </font>
						<b><a style="text-decoration: none" target="_blank" href="https://www.gog.com/en/games?query=Vlak" rel="nofollow">
						<font face="Arial" size="2" color="#FFFF00">GOG</font></a></b>
						<font face="Arial" size="2" color="#C0C0C0">or</font>
						<font face="Arial" color="#FFFFFF" size="2"><b><a style="text-decoration: none" target="_blank" href="https://store.steampowered.com/search/?term=Vlak" 							rel="nofollow">
						<font face="Arial" size="2" color="#FFFF00">Steam</font></a></b><font face="Arial" size="2" color="#FFFFFF">.</font>
					</td></tr>

<!-- *************** konec kódu PRO SBĚRATELE ************************* -->

<!-- *************** začátek kódu OVLÁDÁNÍ ************************* -->

		
					<tr>
						<td colspan='5' style='padding-left: 0px; padding-right: 0px'>
						&nbsp;</td>
					</tr>
					<tr>
						<td colspan='5' style='padding-left: 0px; padding-right: 0px'>
						<b><font face='Arial' size='2' color='#FFFFFF'>Game controls:</font></b></td>
					</tr>
					<tr>
						<td colspan='5' style='padding-left: 0px; padding-right: 0px'>
						<p align='justify'>
						<font face='Arial' size='2' color='#C0C0C0'>
						All DOS games were controlled directly from the PC keyboard. Some newer DOS games also used a mouse or other more advanced game peripherals for control. However, each game 							was controlled by different keys. You can find a detailed description of how to control this version of Vlak in the attached game manual. An overview of basic 							keyboard commands and keyboard shortcuts to control this game is summarized in the following table:						<br>
						&nbsp;</font>
						<table border='1' width='100%' style='border-collapse: collapse'>
							<tr>
								<td width='148' align='center'>
									<b><font face='Arial' size='2' color='#FFFFFF'>Keys</font></b>
								</td>
								<td>
									<p align='left'><b><font face='Arial' size='2' color='#FFFFFF'>Action</font></b>
								</td>
							</tr>

							
					
							<tr>
								<td width='148' align='center'>
									<font face='Arial' size='2' color='#C0C0C0'><kbd>↑</kbd> <kbd>↓</kbd> <kbd>←</kbd> <kbd>→</kbd></font>
								</td>
								<td>
									<p align='justify'>
									<font face='Arial' size='2' color='#C0C0C0'>The direction of locomotive movement: up, down, left, right</font>
								</td>
							</tr>

							
					
							<tr>
								<td width='148' align='center'>
									<font face='Arial' size='2' color='#C0C0C0'><kbd>F1</kbd></font>
								</td>
								<td>
									<p align='justify'>
									<font face='Arial' size='2' color='#C0C0C0'>Show the solution of the level (only version 2.0)</font>
								</td>
							</tr>

							
					
							<tr>
								<td width='148' align='center'>
									<font face='Arial' size='2' color='#C0C0C0'><kbd>F2</kbd></font>
								</td>
								<td>
									<p align='justify'>
									<font face='Arial' size='2' color='#C0C0C0'>Sound on / off (only version 2.0)</font>
								</td>
							</tr>

							
					
							<tr>
								<td width='148' align='center'>
									<font face='Arial' size='2' color='#C0C0C0'><kbd>F4</kbd></font>
								</td>
								<td>
									<p align='justify'>
									<font face='Arial' size='2' color='#C0C0C0'>Enter the password to start selected level</font>
								</td>
							</tr>

													
							
						</table>
						</td>
					</tr>

		

<!-- *************** konec kódu OVLÁDÁNÍ ************************* -->

<!-- *************** začátek kódu HERNÍ KONZOLE ************************* -->

					<tr>
						<td colspan="5" style="padding-left: 0px; padding-right: 0px">
						&nbsp;</td>
					</tr>
					<tr>
						<td colspan="5" style="padding-left: 0px; padding-right: 0px">
						<b><font face="Arial" size="2" color="#FFFFFF">Platform:</font></b></td>
					</tr>
					<tr>
						<td colspan="5" style="padding-left: 0px; padding-right: 0px">
						<p align="justify">
						<font face="Arial" size="2" color="#C0C0C0">
						<img border="0" src="grafika/konzole/PC-DOS_mini.png" width="120" height="115" align="right" hspace="10" onmouseover="showtrail('grafika/konzole/PC-DOS_big.png', 'Personal computer with operating system MS-DOS',524,500)" onmouseout="hidetrail()">
						This ver­sion of Vlak was de­sig­ned for per­so­nal com­pu­ters with o­pe­ra­ting sys­tem MS-DOS (Mi­cro­soft Disk O­pe­ra­ting Sys­tem), 
						which was o­pe­ra­ting sys­tem de­ve­lo­ped by Mi­cro­soft in 1981. It was the most wi­de­ly-used o­pe­ra­ting sys­tem in the first half of the 1990s. MS-DOS was&nbsp;sup­plied 
						with most of the IBM com­pu­ters that pur­cha­sed a li­cen­se from Mi­cro­soft. Af­ter 1995, it was pu­s­hed out by a gra­phi­cal­ly mo­re ad­van­ced sys­tem - Win­dows and
						its de­ve­lop­ment was ce­a­sed in 2000. At the 
						ti­me of its grea­test fa­me, se­ve­ral thou­sand ga­mes de­sig­ned spe­ci­fi­cal­ly for com­pu­ters with this sys­tem we­re cre­a­ted. To­day, its de­ve­lop­ment is no lon­ger con­ti­nue 
						and for e­mu­la­tion the free DOSBox e­mu­la­tor is most of­ten used. Mo­re in­for­ma­ti­on about MS-DOS operating system can be found 
						<a href='https://en.wikipedia.org/wiki/MS-DOS' target='_blank'><font face='Arial' size='2' color='#FFFF00'>here</font></a>.					</font></td>
					</tr>

<!-- *************** konec kódu HERNÍ KONZOLE ************************* -->

<!-- *************** začátek kódu SVĚTOVÝ REKORD ************************* -->

		﻿
				<tr>
					<td colspan="5" style="padding-left: 0px; padding-right: 0px">
					&nbsp;</td>
				</tr>
				<tr>
					<td colspan="5" style="padding-left: 0px; padding-right: 0px">
					<b><font face="Arial" size="2" color="#FFFFFF">World Record:</font></b></td>
				</tr>
				<tr>
					<td colspan="5" style="padding-left: 0px; padding-right: 0px">
					<p align="justify">
					<font face="Arial" size="2" color="#C0C0C0">
					The current world record for this version of Vlak is held by <font color=white>Tutifus</font> from Czech Republic, achieved on 02/02/2025 with a result of <font color=white>33m 47s</font> (as recorded on <a href='https://www.speedrun.com/vlak_train' target='_blank'><font face='Arial' size='2' color='#FFFF00'>Speedrun.com</font></a>). However, for a result to be recognized as an official world record, it must be achieved on the original console without the use of emulators, and must be verified either by a video recording or in the presence of an official referee. So even if you break the record while playing here on our website, it unfortunately won’t be officially accepted. Still, we’d love it if you shared your performance with others in the discussion below – it counts too!				</font></td>
				</tr>
			
<!-- *************** konec kódu SVĚTOVÝ REKORD ************************* -->


<!-- *************** začátek kódu DOSTUPNÉ EMULÁTORY ************************* -->

					<tr>
						<td colspan="5" style="padding-left: 0px; padding-right: 0px">
						<a name="emulatory"></a>&nbsp;</td>
					</tr>
					<tr>
						<td colspan="5" style="padding-left: 0px; padding-right: 0px">
						<b><font face="Arial" size="2" color="#FFFFFF">Available online emulators:</font></b></td>
					</tr>
					<tr>
						<td colspan="5" style="padding-left: 0px; padding-right: 0px">
						<p align="justify">
						<font face="Arial" size="2" color="#C0C0C0">
						5 different online emulators are available for Vlak. These emulators differ not only in the technology they use to emulate old games, but also in 								support of various game controllers, multiplayer mode, mobile phone touchscreen, emulation speed, absence or presence of embedded ads and in many other parameters. For 
						maximum gaming enjoyment, it's important to choose the right emulator, because on each PC and in different Internet browsers, the individual emulators behave differently. The basic 
						features of each emulator available for this game Vlak are summarized in the following table:						
						<br>&nbsp;</font>
						</td>
					</tr>
					<tr><td colspan="5" style="padding-left: 0px; padding-right: 0px">
						<table border="1" width="100%" style="border-collapse: collapse">
							<tr>
								<td>
								<b><font face="Arial" size="2" color="#FFFFFF">Emulator</font></b>
								</td>
								<td width="17%" align="center">
								<b><font face="Arial" size="2" color="#FFFFFF">Technology</font></b>
								</td>
								<td width="17%" align="center">
								<b><font face="Arial" size="2" color="#FFFFFF">Multiplayer</font></b>
								</td>
								<td width="17%" align="center">
								<b><font face="Arial" size="2" color="#FFFFFF">Fullscreen</font></b>
								</td>
								<td width="17%" align="center">
								<b><font face="Arial" size="2" color="#FFFFFF">Touchscreen</font></b>
								</td>
								<td width="17%" align="center">
								<b><font face="Arial" size="2" color="#FFFFFF">Speed</font></b>
								</td>
							</tr>
							<tr>
								<td>
								<b><a style="text-decoration: none" href="?emulator=archive">
								<font face="Arial" size="2" color="#FFFF00">Archive.org</font></a></b>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">JavaScript</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">YES</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">NO</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">NO</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">fast</font>
								</td>
							</tr>
							<tr>
								<td>
								<b><a style="text-decoration: none" href="?emulator=jsdos">
								<font face="Arial" size="2" color="#FF0000">js-dos v3</font></a></b>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">JavaScript</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">YES</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">YES</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">NO</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">fast</font>
								</td>
							</tr>
							<tr>
								<td>
								<b><a style="text-decoration: none" href="?emulator=jsdos622">
								<font face="Arial" size="2" color="#FFFF00">js-dos 6.22</font></a></b>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">JavaScript</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">YES</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">YES</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">NO</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">fast</font>
								</td>
							</tr>
							<tr>
								<td>
								<b><a style="text-decoration: none" href="?emulator=jsdosbox">
								<font face="Arial" size="2" color="#FFFF00">jsDosBox</font></a></b>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">JavaScript</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">YES</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">NO</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">NO</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">slow</font>
								</td>
							</tr>
							<tr>
								<td>
								<b><a style="text-decoration: none" href="?emulator=java">
								<font face="Arial" size="2" color="#FFFF00">jDosBox</font></a></b>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">Java applet</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">YES</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">YES</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">NO</font>
								</td>
								<td width="17%" align="center">
								<font face="Arial" size="2" color="#C0C0C0">fast</font>
								</td>
							</tr>
						</table>
						</td></tr>

<!-- *************** konec kódu DOSTUPNÉ EMULÁTORY ************************* -->

					</table>
                
                                                
                </td>
              </tr>
            </table>


<!-- -->

	<!-- ﻿-->


	<p align="center">

	﻿﻿

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9073967042072978"
     crossorigin="anonymous"></script>
<ins class="adsbygoogle"
     style="display:inline-block;width:740px;height:178px"
     data-ad-client="ca-pub-9073967042072978"
     data-ad-slot="5837103892"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

				

<!-- -->

	<br>

	  <!-- ﻿-->



	<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px solid #FFFFFF" bordercolor="#FFFFFF" width="757" id="AutoNumber10">
              <tr>
                <td width="100%" bgcolor="#333333" style="padding-left: 7; padding-right: 7">
                <font face="Arial Black" color="#FFFF00"><span lang="cs">Similar games:</span></font></td>
              </tr>
              <tr>
                <td width="100%" style="padding:9; padding-top:15;">

			<p align='justify'>
			<font face='Arial' size='2' color='#C0C0C0'>
			If you like Vlak you'll probably like also some of the similar games in the overview below. The games you see here 
				are selected based on title similarity, game genre, and keywords. However, the list is generated automatically and can therefore be very 'subjective' 
				especially for some specific games. To find a particular game, please use our <a href='advsearch_form.php'><font face='Arial' size='2' color='#FFFF00'>search form</font></a>.			<br>
			</font>
			</p>
                
                
					<table border="0" width="100%" cellspacing="0" cellpadding="0" bgcolor="#000000">
					<tr>
						
						<td align="center" width="20%" style="padding-top: 5px">
						<a href="play_237-Atari2600.php" onFocus="if(this.blur)this.blur();"><img border="1" alt="Surround" src="games/237/01.gif" style="border: 1px solid #808080" width="120" height="90" id='linkNES1'></a>
								<script>
								/*
								Preload images script
								*/
								var myimages=new Array()
								function preloadimages(){
								for (i=0;i<preloadimages.arguments.length;i++){
								myimages[i]=new Image()
								myimages[i].src=preloadimages.arguments[i]
								}
								}
								preloadimages('games/237/00.gif','games/237/01.gif','games/237/02.gif','games/237/03.gif')
								</script>

								<script type='text/javascript' src='multiswap.js'>
								</script>
								<script type='text/javascript'>
								new MultiSwap('linkNES1', 500, 'games/237/02.gif','games/237/03.gif','games/237/00.gif','games/237/01.gif');
								</script>
						</td>

						
						<td align="center" width="20%" style="padding-top: 5px">
						<a href="play_1286-Atari2600.php" onFocus="if(this.blur)this.blur();"><img border="1" alt="Tapeworm" src="games/1286/01.gif" style="border: 1px solid #808080" width="120" height="90" id='linkNES2'></a>
								<script>
								/*
								Preload images script
								*/
								var myimages=new Array()
								function preloadimages(){
								for (i=0;i<preloadimages.arguments.length;i++){
								myimages[i]=new Image()
								myimages[i].src=preloadimages.arguments[i]
								}
								}
								preloadimages('games/1286/00.gif','games/1286/01.gif','games/1286/02.gif','games/1286/03.gif')
								</script>

								<script type='text/javascript' src='multiswap.js'>
								</script>
								<script type='text/javascript'>
								new MultiSwap('linkNES2', 500, 'games/1286/02.gif','games/1286/03.gif','games/1286/00.gif','games/1286/01.gif');
								</script>
						</td>

						
						<td align="center" width="20%" style="padding-top: 5px">
						<a href="play_1620-DOS.php" onFocus="if(this.blur)this.blur();"><img border="1" alt="QBasic Nibbles" src="games/1620/01.gif" style="border: 1px solid #808080" width="120" height="90" id='linkNES3'></a>
								<script>
								/*
								Preload images script
								*/
								var myimages=new Array()
								function preloadimages(){
								for (i=0;i<preloadimages.arguments.length;i++){
								myimages[i]=new Image()
								myimages[i].src=preloadimages.arguments[i]
								}
								}
								preloadimages('games/1620/00.gif','games/1620/01.gif','games/1620/02.gif','games/1620/03.gif')
								</script>

								<script type='text/javascript' src='multiswap.js'>
								</script>
								<script type='text/javascript'>
								new MultiSwap('linkNES3', 500, 'games/1620/02.gif','games/1620/03.gif','games/1620/00.gif','games/1620/01.gif');
								</script>
						</td>

						
						<td align="center" width="20%" style="padding-top: 5px">
						<a href="play_1285-DOS.php" onFocus="if(this.blur)this.blur();"><img border="1" alt="Achtung, die Kurve!" src="games/1285/01.gif" style="border: 1px solid #808080" width="120" height="90" id='linkNES4'></a>
								<script>
								/*
								Preload images script
								*/
								var myimages=new Array()
								function preloadimages(){
								for (i=0;i<preloadimages.arguments.length;i++){
								myimages[i]=new Image()
								myimages[i].src=preloadimages.arguments[i]
								}
								}
								preloadimages('games/1285/00.gif','games/1285/01.gif','games/1285/02.gif','games/1285/03.gif')
								</script>

								<script type='text/javascript' src='multiswap.js'>
								</script>
								<script type='text/javascript'>
								new MultiSwap('linkNES4', 500, 'games/1285/02.gif','games/1285/03.gif','games/1285/00.gif','games/1285/01.gif');
								</script>
						</td>

						
						<td align="center" width="20%" style="padding-top: 5px">
						<a href="play_866-NES.php" onFocus="if(this.blur)this.blur();"><img border="1" alt="Qix" src="games/866/01.gif" style="border: 1px solid #808080" width="120" height="90" id='linkNES5'></a>
								<script>
								/*
								Preload images script
								*/
								var myimages=new Array()
								function preloadimages(){
								for (i=0;i<preloadimages.arguments.length;i++){
								myimages[i]=new Image()
								myimages[i].src=preloadimages.arguments[i]
								}
								}
								preloadimages('games/866/00.gif','games/866/01.gif','games/866/02.gif','games/866/03.gif')
								</script>

								<script type='text/javascript' src='multiswap.js'>
								</script>
								<script type='text/javascript'>
								new MultiSwap('linkNES5', 500, 'games/866/02.gif','games/866/03.gif','games/866/00.gif','games/866/01.gif');
								</script>
						</td>

						
												
					</tr>
					<tr>
						
						<td align="center" width="20%" style="padding-bottom: 3px">
						<a href="play_237-Atari2600.php" style="text-decoration: none">
						<b><font face="Arial" size="1" color="#FFFF00">Surround</font></b></a>
						</td>

						
						<td align="center" width="20%" style="padding-bottom: 3px">
						<a href="play_1286-Atari2600.php" style="text-decoration: none">
						<b><font face="Arial" size="1" color="#FFFF00">Tapeworm</font></b></a>
						</td>

						
						<td align="center" width="20%" style="padding-bottom: 3px">
						<a href="play_1620-DOS.php" style="text-decoration: none">
						<b><font face="Arial" size="1" color="#FFFF00">QBasic Nibbles</font></b></a>
						</td>

						
						<td align="center" width="20%" style="padding-bottom: 3px">
						<a href="play_1285-DOS.php" style="text-decoration: none">
						<b><font face="Arial" size="1" color="#FFFF00">Achtung, die Kurve!</font></b></a>
						</td>

						
						<td align="center" width="20%" style="padding-bottom: 3px">
						<a href="play_866-NES.php" style="text-decoration: none">
						<b><font face="Arial" size="1" color="#FFFF00">Qix</font></b></a>
						</td>

						
					</tr>

					<tr>
					<td><font face="Arial" size="1" color="#FFFF00"> &nbsp;</font> </td><td> </td><td> </td><td> </td><td> </td>
					</tr>

					<tr>
						
						<td align="center" width="20%" style="padding-top: 5px">
						<a href="play_1639-DOS.php" onFocus="if(this.blur)this.blur();"><img border="1" alt="Tetris Classic" src="games/1639/01.gif" style="border: 1px solid #808080" width="120" height="90" id='linkNES6'></a>
								<script>
								/*
								Preload images script
								*/
								var myimages=new Array()
								function preloadimages(){
								for (i=0;i<preloadimages.arguments.length;i++){
								myimages[i]=new Image()
								myimages[i].src=preloadimages.arguments[i]
								}
								}
								preloadimages('games/1639/00.gif','games/1639/01.gif','games/1639/02.gif','games/1639/03.gif')
								</script>

								<script type='text/javascript' src='multiswap.js'>
								</script>
								<script type='text/javascript'>
								new MultiSwap('linkNES6', 500, 'games/1639/02.gif','games/1639/03.gif','games/1639/00.gif','games/1639/01.gif');
								</script>
						</td>

						
						<td align="center" width="20%" style="padding-top: 5px">
						<a href="play_1676-Genesis.php" onFocus="if(this.blur)this.blur();"><img border="1" alt="Zoom!" src="games/1676/01.gif" style="border: 1px solid #808080" width="120" height="90" id='linkNES7'></a>
								<script>
								/*
								Preload images script
								*/
								var myimages=new Array()
								function preloadimages(){
								for (i=0;i<preloadimages.arguments.length;i++){
								myimages[i]=new Image()
								myimages[i].src=preloadimages.arguments[i]
								}
								}
								preloadimages('games/1676/00.gif','games/1676/01.gif','games/1676/02.gif','games/1676/03.gif')
								</script>

								<script type='text/javascript' src='multiswap.js'>
								</script>
								<script type='text/javascript'>
								new MultiSwap('linkNES7', 500, 'games/1676/02.gif','games/1676/03.gif','games/1676/00.gif','games/1676/01.gif');
								</script>
						</td>

						
						<td align="center" width="20%" style="padding-top: 5px">
						<a href="play_061-NES.php" onFocus="if(this.blur)this.blur();"><img border="1" alt="Dr. Mario" src="games/061/01.gif" style="border: 1px solid #808080" width="120" height="90" id='linkNES8'></a>
								<script>
								/*
								Preload images script
								*/
								var myimages=new Array()
								function preloadimages(){
								for (i=0;i<preloadimages.arguments.length;i++){
								myimages[i]=new Image()
								myimages[i].src=preloadimages.arguments[i]
								}
								}
								preloadimages('games/061/00.gif','games/061/01.gif','games/061/02.gif','games/061/03.gif')
								</script>

								<script type='text/javascript' src='multiswap.js'>
								</script>
								<script type='text/javascript'>
								new MultiSwap('linkNES8', 500, 'games/061/02.gif','games/061/03.gif','games/061/00.gif','games/061/01.gif');
								</script>
						</td>

						
						<td align="center" width="20%" style="padding-top: 5px">
						<a href="play_267-Atari2600.php" onFocus="if(this.blur)this.blur();"><img border="1" alt="Amidar" src="games/267/01.gif" style="border: 1px solid #808080" width="120" height="90" id='linkNES9'></a>
								<script>
								/*
								Preload images script
								*/
								var myimages=new Array()
								function preloadimages(){
								for (i=0;i<preloadimages.arguments.length;i++){
								myimages[i]=new Image()
								myimages[i].src=preloadimages.arguments[i]
								}
								}
								preloadimages('games/267/00.gif','games/267/01.gif','games/267/02.gif','games/267/03.gif')
								</script>

								<script type='text/javascript' src='multiswap.js'>
								</script>
								<script type='text/javascript'>
								new MultiSwap('linkNES9', 500, 'games/267/02.gif','games/267/03.gif','games/267/00.gif','games/267/01.gif');
								</script>
						</td>

						
						<td align="center" width="20%" style="padding-top: 5px">
						<a href="play_1632-SNES.php" onFocus="if(this.blur)this.blur();"><img border="1" alt="Tetris Attack" src="games/1632/01.gif" style="border: 1px solid #808080" width="120" height="90" id='linkNES10'></a>
								<script>
								/*
								Preload images script
								*/
								var myimages=new Array()
								function preloadimages(){
								for (i=0;i<preloadimages.arguments.length;i++){
								myimages[i]=new Image()
								myimages[i].src=preloadimages.arguments[i]
								}
								}
								preloadimages('games/1632/00.gif','games/1632/01.gif','games/1632/02.gif','games/1632/03.gif')
								</script>

								<script type='text/javascript' src='multiswap.js'>
								</script>
								<script type='text/javascript'>
								new MultiSwap('linkNES10', 500, 'games/1632/02.gif','games/1632/03.gif','games/1632/00.gif','games/1632/01.gif');
								</script>
						</td>

						
												
					</tr>
					<tr>
						
						<td align="center" width="20%" style="padding-bottom: 3px">
						<a href="play_1639-DOS.php" style="text-decoration: none">
						<b><font face="Arial" size="1" color="#FFFF00">Tetris Classic</font></b></a>
						</td>

						
						<td align="center" width="20%" style="padding-bottom: 3px">
						<a href="play_1676-Genesis.php" style="text-decoration: none">
						<b><font face="Arial" size="1" color="#FFFF00">Zoom!</font></b></a>
						</td>

						
						<td align="center" width="20%" style="padding-bottom: 3px">
						<a href="play_061-NES.php" style="text-decoration: none">
						<b><font face="Arial" size="1" color="#FFFF00">Dr. Mario</font></b></a>
						</td>

						
						<td align="center" width="20%" style="padding-bottom: 3px">
						<a href="play_267-Atari2600.php" style="text-decoration: none">
						<b><font face="Arial" size="1" color="#FFFF00">Amidar</font></b></a>
						</td>

						
						<td align="center" width="20%" style="padding-bottom: 3px">
						<a href="play_1632-SNES.php" style="text-decoration: none">
						<b><font face="Arial" size="1" color="#FFFF00">Tetris Attack</font></b></a>
						</td>

						
					</tr>

					<tr>
					<td><font face="Arial" size="1" color="#FFFF00"> &nbsp;</font> </td><td> </td><td> </td><td> </td><td> </td>
					</tr>

					<tr>
						
						<td align="center" width="20%" style="padding-top: 5px">
						<a href="play_1546-SNES.php" onFocus="if(this.blur)this.blur();"><img border="1" alt="Plok" src="games/1546/01.gif" style="border: 1px solid #808080" width="120" height="90" id='linkNES11'></a>
								<script>
								/*
								Preload images script
								*/
								var myimages=new Array()
								function preloadimages(){
								for (i=0;i<preloadimages.arguments.length;i++){
								myimages[i]=new Image()
								myimages[i].src=preloadimages.arguments[i]
								}
								}
								preloadimages('games/1546/00.gif','games/1546/01.gif','games/1546/02.gif','games/1546/03.gif')
								</script>

								<script type='text/javascript' src='multiswap.js'>
								</script>
								<script type='text/javascript'>
								new MultiSwap('linkNES11', 500, 'games/1546/02.gif','games/1546/03.gif','games/1546/00.gif','games/1546/01.gif');
								</script>
						</td>

						
						<td align="center" width="20%" style="padding-top: 5px">
						<a href="play_1690-DOS.php" onFocus="if(this.blur)this.blur();"><img border="1" alt="Dr. Rudy" src="games/1690/01.gif" style="border: 1px solid #808080" width="120" height="90" id='linkNES12'></a>
								<script>
								/*
								Preload images script
								*/
								var myimages=new Array()
								function preloadimages(){
								for (i=0;i<preloadimages.arguments.length;i++){
								myimages[i]=new Image()
								myimages[i].src=preloadimages.arguments[i]
								}
								}
								preloadimages('games/1690/00.gif','games/1690/01.gif','games/1690/02.gif','games/1690/03.gif')
								</script>

								<script type='text/javascript' src='multiswap.js'>
								</script>
								<script type='text/javascript'>
								new MultiSwap('linkNES12', 500, 'games/1690/02.gif','games/1690/03.gif','games/1690/00.gif','games/1690/01.gif');
								</script>
						</td>

						
						<td align="center" width="20%" style="padding-top: 5px">
						<a href="play_1538-SNES.php" onFocus="if(this.blur)this.blur();"><img border="1" alt="Axelay" src="games/1538/01.gif" style="border: 1px solid #808080" width="120" height="90" id='linkNES13'></a>
								<script>
								/*
								Preload images script
								*/
								var myimages=new Array()
								function preloadimages(){
								for (i=0;i<preloadimages.arguments.length;i++){
								myimages[i]=new Image()
								myimages[i].src=preloadimages.arguments[i]
								}
								}
								preloadimages('games/1538/00.gif','games/1538/01.gif','games/1538/02.gif','games/1538/03.gif')
								</script>

								<script type='text/javascript' src='multiswap.js'>
								</script>
								<script type='text/javascript'>
								new MultiSwap('linkNES13', 500, 'games/1538/02.gif','games/1538/03.gif','games/1538/00.gif','games/1538/01.gif');
								</script>
						</td>

						
						<td align="center" width="20%" style="padding-top: 5px">
						<a href="play_724-DOS.php" onFocus="if(this.blur)this.blur();"><img border="1" alt="D/Generation" src="games/724/01.gif" style="border: 1px solid #808080" width="120" height="90" id='linkNES14'></a>
								<script>
								/*
								Preload images script
								*/
								var myimages=new Array()
								function preloadimages(){
								for (i=0;i<preloadimages.arguments.length;i++){
								myimages[i]=new Image()
								myimages[i].src=preloadimages.arguments[i]
								}
								}
								preloadimages('games/724/00.gif','games/724/01.gif','games/724/02.gif','games/724/03.gif')
								</script>

								<script type='text/javascript' src='multiswap.js'>
								</script>
								<script type='text/javascript'>
								new MultiSwap('linkNES14', 500, 'games/724/02.gif','games/724/03.gif','games/724/00.gif','games/724/01.gif');
								</script>
						</td>

						
						<td align="center" width="20%" style="padding-top: 5px">
						<a href="play_1551-N64.php" onFocus="if(this.blur)this.blur();"><img border="1" alt="Blast Corps" src="games/1551/01.gif" style="border: 1px solid #808080" width="120" height="90" id='linkNES15'></a>
								<script>
								/*
								Preload images script
								*/
								var myimages=new Array()
								function preloadimages(){
								for (i=0;i<preloadimages.arguments.length;i++){
								myimages[i]=new Image()
								myimages[i].src=preloadimages.arguments[i]
								}
								}
								preloadimages('games/1551/00.gif','games/1551/01.gif','games/1551/02.gif','games/1551/03.gif')
								</script>

								<script type='text/javascript' src='multiswap.js'>
								</script>
								<script type='text/javascript'>
								new MultiSwap('linkNES15', 500, 'games/1551/02.gif','games/1551/03.gif','games/1551/00.gif','games/1551/01.gif');
								</script>
						</td>

						
												
					</tr>
					<tr>
						
						<td align="center" width="20%" style="padding-bottom: 3px">
						<a href="play_1546-SNES.php" style="text-decoration: none">
						<b><font face="Arial" size="1" color="#FFFF00">Plok</font></b></a>
						</td>

						
						<td align="center" width="20%" style="padding-bottom: 3px">
						<a href="play_1690-DOS.php" style="text-decoration: none">
						<b><font face="Arial" size="1" color="#FFFF00">Dr. Rudy</font></b></a>
						</td>

						
						<td align="center" width="20%" style="padding-bottom: 3px">
						<a href="play_1538-SNES.php" style="text-decoration: none">
						<b><font face="Arial" size="1" color="#FFFF00">Axelay</font></b></a>
						</td>

						
						<td align="center" width="20%" style="padding-bottom: 3px">
						<a href="play_724-DOS.php" style="text-decoration: none">
						<b><font face="Arial" size="1" color="#FFFF00">D/Generation</font></b></a>
						</td>

						
						<td align="center" width="20%" style="padding-bottom: 3px">
						<a href="play_1551-N64.php" style="text-decoration: none">
						<b><font face="Arial" size="1" color="#FFFF00">Blast Corps</font></b></a>
						</td>

						
					</tr>

				</table>
				</div>                                
                </td>
              </tr>
            </table>


<!-- -->

	<br>
	
           <!-- ﻿-->

	<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 1px solid #FFFFFF" bordercolor="#FFFFFF" width="757" id="AutoNumber9">
              <tr>
                <td width="100%" bgcolor="#333333" style="padding-left: 7; padding-right: 7">
                <font face="Arial Black" color="#FFFF00">Comments:</font></td>
              </tr>
              <tr>
                <td width="100%" bgcolor="#B1B5B8" style="padding: 7">

		


	<div id="fb-msg"
		style="padding:0px;
		margin:1em 0;
		background:#B1B5B8;
		color:#000;
		font-size:12px;
		font-family:'Arial', Arial, sans-serif;">
		Comments are visible only to users who are logged in to their <a href='https://www.facebook.com/login.php' target='_blank' style='color:#1877F2; text-decoration:none;'>Facebook</a> account.	</div>

	<div id="fb-comments"
	     class="fb-comments"
	     data-href="http://www.retrogames.cz/play_487-DOS.php"
	     data-numposts="10"
	     data-width="740"
	     data-colorscheme="light"
	     data-order-by="reverse_time"></div>

	<script>
	(() => {
	  const msg = document.getElementById('fb-msg');
	  const box = document.getElementById('fb-comments');

	  const rendered = () => box && box.getBoundingClientRect().height > 120;

	  const tryHide = () => {
	    if (rendered()) msg.style.display = 'none';
	  };

	  // 1) zkus to průběžně (FB často mění výšku postupně)
	  const iv = setInterval(() => {
	    tryHide();
	    if (msg.style.display === 'none') clearInterval(iv);
	  }, 200);

	  // 2) reaguj i na DOM změny v rámci boxu
	  const mo = new MutationObserver(() => {
	    tryHide();
	    if (msg.style.display === 'none') mo.disconnect();
	  });
	  mo.observe(box, { childList: true, subtree: true, attributes: true });

	  // 3) po 8s to stopni (hláška zůstane)
	  setTimeout(() => { clearInterval(iv); mo.disconnect(); }, 8000);
	})();
	</script>



		
                         
                </td>
              </tr>
	</table>

<!-- -->
         
	<br>


	<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border: 0px solid #FFFFFF" bordercolor="#FFFFFF" width="757" id="AutoNumber10">
		<tr>
		<td width="518" valign="top" style="padding-top: 5">


	    <!-- ﻿-->

<!-- ShareThis BEGIN -->
<div class="sharethis-inline-share-buttons"></div>
<!-- ShareThis END -->

<!-- -->

		</td>
		</tr>
	</table>
	<br>
	

      
      </td>
      <td bgcolor="#000000" width="15">&nbsp;</td>
    </tr>
  </table>
  </center>
</div>

<!-- ﻿-->

<p align="center" style="margin-top: 8px"><font face="Arial" size="1">

<!-- ﻿-->

<a href="https://www.toplist.cz/stat/1142145" rel="nofollow"><script language="JavaScript" type="text/javascript">
<!--
document.write('<img src="https://toplist.cz/dot.asp?id=1142145&http='+escape(document.referrer)+'&t='+escape(document.title)+
'&wi='+escape(window.screen.width)+'&he='+escape(window.screen.height)+'&cd='+escape(window.screen.colorDepth)+'" width="1" height="1" border=0 alt="TOPlist" />');
//--></script><noscript><img src="https://toplist.cz/dot.asp?id=1142145" border="0"
alt="TOPlist" width="1" height="1" /></noscript></a>

<!-- -->

<!-- ﻿-->
<!-- -->



This website is NOT sponsored or endorsed by Nintendo, Atari, Sega or by any other video games company. 
<a style="text-decoration: none; color: #000000; font-weight: bold" href="//www.retrogames.cz">RetroGames.cz</a> makes no claim to the intellectual property contained in the individual games.<br>
Text content of <a style="text-decoration: none; color: #000000; font-weight: bold" href="//www.retrogames.cz">RetroGames.cz</a> 
is available under the 
<a style="text-decoration: none; color: #000000; font-weight: bold" href="https://creativecommons.org/licenses/by-sa/3.0/deed.en">
Creative Commons 3.0 License</a>. You can copy it freely, but indicate the origin and keep the license.<br><br>
<a style="text-decoration: none; color: #000000; font-weight: bold" rel="nofollow" href="https://www.facebook.com/retrogames.cz/" target="_blank">Facebook</a> | 
<a style="text-decoration: none; color: #000000; font-weight: bold" href="privacy.php">Privacy policy</a> | 
<a style="text-decoration: none; color: #000000; font-weight: bold" href="terms.php">Terms of Service</a> | 
<a style="text-decoration: none; color: #000000; font-weight: bold" href="cookie_statement.php">Cookie statement</a> |
<a style="text-decoration: none; color: #000000; font-weight: bold" href="PR.pdf" target="_blank">Advertisement</a> |  
<a style="text-decoration: none; color: #000000; font-weight: bold" href="report.php">Report NA content</a><br><br>
This website is hosted by <a href="https://www.websupport.cz/?ref=ND4pFF49" rel="nofollow" style="text-decoration: none; color: #000000; font-weight: bold" target="_blank">WebSupport.cz</a>.
</font>
<br><br>

<!-- ﻿-->

﻿﻿

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9073967042072978"
     crossorigin="anonymous"></script>
<ins class="adsbygoogle"
     style="display:inline-block;width:980px;height:200px"
     data-ad-client="ca-pub-9073967042072978"
     data-ad-slot="7701129140"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>


			
<br>

<!-- -->

<br><br><br><br><br><br>


</p>


<!-- -->

</td>
<td valign="top" style="border-style: outset; border-width: 0px; padding-left: 10px">
<!-- ﻿-->


	<div style='position: fixed; top: 29px;'>
	﻿﻿

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9073967042072978"
     crossorigin="anonymous"></script>
<!-- boční sloupec vpravo -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9073967042072978"
     data-ad-slot="7037021738"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>


		
<div id="adblock-content"></div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Vytvoření testovacího prvku
            var adTest = document.createElement('div');
            adTest.className = 'adsbox'; // Funkční třída pro detekci
            adTest.style.height = '1px';
            adTest.style.width = '1px';
            adTest.style.position = 'absolute';
            adTest.style.left = '-9999px';
            document.body.appendChild(adTest);

            setTimeout(function () {
                if (adTest.offsetHeight === 0) {
                    console.log('AdBlock detected');
                    // Dynamické načtení obsahu z PHP souboru
                    var xhr = new XMLHttpRequest();
                    xhr.open('GET', 'dynamic-content.php?cache=' + Date.now(), true);
                    xhr.onreadystatechange = function () {
                        if (xhr.readyState === 4 && xhr.status === 200) {
                            document.getElementById('adblock-content').innerHTML = xhr.responseText;
                        } else if (xhr.readyState === 4) {
                            console.error('Error loading content:', xhr.statusText);
                        }
                    };
                    xhr.send();
                } else {
                    console.log('No AdBlock detected');
                }
                document.body.removeChild(adTest); // Odstranění testovacího prvku
            }, 100);
        });
    </script>


<script data-name="BMC-Widget" data-cfasync="false" src="https://cdnjs.buymeacoffee.com/1.0.0/widget.prod.min.js" data-id="RetroGames.cz" data-description="Support us on Buy us a beer!" data-message="" data-color="#FF813F" data-position="Right" data-x_margin="18" data-y_margin="18"></script>
	</div>

			

<!-- -->
</td>

<td valign="top" style="border-style: outset; border-width: 0px; padding-left: 0px;">
<!-- ﻿-->



	<div style='position: fixed; top: 26px;'>
	<table style="margin-left:
	-1180px;	">
	<tr><td>

	﻿﻿

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9073967042072978"
     crossorigin="anonymous"></script>
<!-- levý sloupec -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-9073967042072978"
     data-ad-slot="5945072242"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>


		
	</td></tr>
	</table>
	</div>

			

<!-- -->
</td>

</tr>
</table>

</body>

<!-- -->

</html>